# Scholar Project - bmpPic

This is a scholar project for the Structured Programming Class at ITESO.

### Usage
